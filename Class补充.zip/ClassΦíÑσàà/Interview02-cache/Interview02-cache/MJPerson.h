//
//  MJPerson.h
//  Interview02-cache
//
//  Created by MJ Lee on 2018/5/19.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MJPerson : NSObject
- (void)personTest;
- (void)personTest2;
- (void)personTest3;

//_key = @selector(personTest)
//_imp = personTest的地址
@end
