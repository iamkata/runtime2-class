//
//  MJPerson.m
//  Interview02-cache
//
//  Created by MJ Lee on 2018/5/19.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson.h"

@implementation MJPerson
- (void)personTest
{
    
}
- (void)personTest2
{
    
}
@end
