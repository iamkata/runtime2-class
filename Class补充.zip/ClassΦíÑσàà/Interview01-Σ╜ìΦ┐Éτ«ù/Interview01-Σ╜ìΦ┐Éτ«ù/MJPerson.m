//
//  MJPerson.m
//  Interview01-位运算
//
//  Created by MJ Lee on 2018/5/19.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson.h"

@implementation MJPerson
- (int)test:(int)age height:(float)height
{
    NSLog(@"%s", __func__);
    return 0;
}

- (void)dealloc
{
    
}
@end
