//
//  main.m
//  Interview01-cache
//
//  Created by MJ Lee on 2018/5/22.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJGoodStudent.h"
#import "MJClassInfo.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        MJPerson *person = [[MJPerson alloc] init];
//        mj_objc_class *personClass = (__bridge mj_objc_class *)[MJPerson class];
//
//        [person personTest];
//
//        NSLog(@"123");
        
        MJGoodStudent *goodStudent = [[MJGoodStudent alloc] init];
        mj_objc_class *goodStudentClass = (__bridge mj_objc_class *)[MJGoodStudent class];

        [goodStudent goodStudentTest];
        [goodStudent studentTest];
        [goodStudent personTest];
        [goodStudent goodStudentTest];
        [goodStudent studentTest];
       
        cache_t cache = goodStudentClass->cache;

        bucket_t *buckets = cache._buckets;

        NSLog(@"--------------------------");
        for (int i = 0; i <= cache._mask; i++) {
            bucket_t bucket = buckets[i];
            NSLog(@"%s %p", bucket._key, bucket._imp);
        }
//        2019-12-05 16:50:25.287650+0800 Interview01-cache[18105:1374729] goodStudentTest 0x100000bc0
//        2019-12-05 16:50:25.287661+0800 Interview01-cache[18105:1374729] personTest 0x100000e20
//        2019-12-05 16:50:25.287670+0800 Interview01-cache[18105:1374729] (null) 0x0
//        2019-12-05 16:50:25.287678+0800 Interview01-cache[18105:1374729] (null) 0x0
//        2019-12-05 16:50:25.287686+0800 Interview01-cache[18105:1374729] studentTest 0x100000b90
//        2019-12-05 16:50:25.287694+0800 Interview01-cache[18105:1374729] (null) 0x0
//        2019-12-05 16:50:25.287852+0800 Interview01-cache[18105:1374729] (null) 0x0
//        2019-12-05 16:50:25.287864+0800 Interview01-cache[18105:1374729] (null) 0x0
       
        NSLog(@"--------------------------");
        
        //有可能算出的索引不是你想要的
        bucket_t bucket = buckets[(long long)@selector(studentTest) & cache._mask];
        NSLog(@"%s %p", bucket._key, bucket._imp);
        
//        2019-12-05 17:08:47.565079+0800 Interview01-cache[18351:1387851] studentTest 0x100001980
        
        NSLog(@"--------------------------");
        //模仿系统，传入key，自动生成索引，然后再找索引对应的值
        NSLog(@"%s %p", @selector(personTest), cache.imp(@selector(personTest)));
        NSLog(@"%s %p", @selector(studentTest), cache.imp(@selector(studentTest)));
        NSLog(@"%s %p", @selector(goodStudentTest), cache.imp(@selector(goodStudentTest)));
        
//        2019-12-05 17:08:47.565097+0800 Interview01-cache[18351:1387851] personTest 0x100001e10
//        2019-12-05 17:08:47.565107+0800 Interview01-cache[18351:1387851] studentTest 0x100001980
//        2019-12-05 17:08:47.565117+0800 Interview01-cache[18351:1387851] goodStudentTest 0x1000019b0
    }
    return 0;
}
